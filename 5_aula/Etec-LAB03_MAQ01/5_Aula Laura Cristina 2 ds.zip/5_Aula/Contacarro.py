class Carro:
    modelo = 0
    marca = 0
    ano = 0
    km = 0
    cor = ""
    def __int__(self):
        print("Objeto carro criado!")

    def ligar(self):
        print(f"Carro {self.modelo} ligado")

carro1 = Carro()

carro1.modelo = "Creta"
carro1.marca = "Hyundai"
carro1.ano = "2022"
carro1.km = "60000"
carro1.cor = "Branca"
carro1.ligar()