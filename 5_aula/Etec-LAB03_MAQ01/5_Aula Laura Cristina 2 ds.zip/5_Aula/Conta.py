class Conta:
    numero = "00000"
    saldo = 0.0

    def __init__(self):
      print ("Criando objeto!")

    def depositar(self,valor):
        self.saldo = self.saldo + valor

c1 = Conta()
c2 = Conta()
c3 = Conta()

print(f"Conta1 indefinida: {c1.numero} possui saldo inicial de {c1.saldo}")

c1.numero = "12345-6"
c1.saldo = 100.0

print(f"Conta1: {c1.numero} possui saldo de {c1.saldo}")

c1.depositar(200)

print(f"Conta1: {c1.numero} possui saldo de {c1.saldo}")

print(f"Conta2 indefinida: {c2.numero} possui saldo inicial de {c2.saldo}")

c2.numero = "45678-9"
c2.saldo = 999.9

print(f"Conta2: {c2.numero} possui saldo de {c2.saldo}")


print(f"Conta3 indefinida: {c3.numero} possui saldo inicial de {c3.saldo}")

c3.numero = "47630-1"
c3.saldo = 111.0

print(f"Conta3: {c3.numero} possui saldo de {c3.saldo}")